# SPORT+ PRO 3.0

Loja esportiva com visual moderno e banco de dados integrado.

## Tecnologias
- HTML5
- CSS3
- JavaScript
- Node.js + Express
- SQLite

## Páginas
1. Início
2. Produtos
3. Vendas
4. Relatórios
5. Clientes
6. Configurações

## Como rodar no GitHub Codespaces

```bash
npm install
npm start
```

Depois abra a porta `3000`.

O banco `sportplus.db` é criado automaticamente na primeira execução e recebe produtos e clientes de exemplo.

## Importante sobre GitHub Pages

O GitHub Pages hospeda páginas estáticas e não executa Node.js/Express nem SQLite. Por isso, para usar o banco integrado, rode o projeto em um ambiente que execute Node.js (por exemplo, Codespaces ou um serviço de hospedagem de backend). O repositório GitHub pode continuar sendo usado para guardar todo o código.
