const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const db = new sqlite3.Database(path.join(__dirname, "sportplus.db"));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS produtos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    categoria TEXT NOT NULL,
    marca TEXT NOT NULL,
    preco REAL NOT NULL,
    estoque INTEGER NOT NULL DEFAULT 0,
    icone TEXT DEFAULT '🏆',
    destaque INTEGER DEFAULT 0,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT,
    email TEXT,
    cidade TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS vendas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER,
    total REAL NOT NULL,
    forma_pagamento TEXT NOT NULL,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(cliente_id) REFERENCES clientes(id)
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS itens_venda (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    venda_id INTEGER NOT NULL,
    produto_id INTEGER NOT NULL,
    quantidade INTEGER NOT NULL,
    preco_unitario REAL NOT NULL,
    FOREIGN KEY(venda_id) REFERENCES vendas(id),
    FOREIGN KEY(produto_id) REFERENCES produtos(id)
  )`);

  db.get("SELECT COUNT(*) AS total FROM produtos", (err, row) => {
    if (!err && row.total === 0) seed();
  });

  db.get("SELECT COUNT(*) AS total FROM clientes", (err, row) => {
    if (!err && row.total === 0) {
      const stmt = db.prepare("INSERT INTO clientes (nome, telefone, email, cidade) VALUES (?, ?, ?, ?)");
      [
        ["Pedro Henrique", "(46) 99999-1111", "pedro@email.com", "Capanema - PR"],
        ["Ana Souza", "(46) 99888-2222", "ana@email.com", "Capanema - PR"],
        ["Lucas Martins", "(46) 99777-3333", "lucas@email.com", "Realeza - PR"]
      ].forEach(c => stmt.run(c));
      stmt.finalize();
    }
  });
});

function seed() {
  const produtos = [
    ["Tênis Air Runner", "Tênis", "Nike", 599.90, 18, "👟", 1],
    ["Tênis Ultraboost", "Tênis", "Adidas", 749.90, 12, "👟", 1],
    ["Tênis Gel Pulse", "Tênis", "Asics", 529.90, 15, "👟", 1],
    ["Tênis Corre 4", "Tênis", "Olympikus", 399.90, 20, "👟", 0],
    ["Chuteira Campo Future", "Chuteira", "Puma", 699.90, 9, "⚽", 1],
    ["Chuteira Society Speed", "Chuteira", "Umbro", 449.90, 14, "⚽", 0],
    ["Chuteira Futsal Pro", "Chuteira", "Penalty", 329.90, 11, "⚽", 0],
    ["Bola Campo Oficial", "Bolas", "Penalty", 189.90, 24, "⚽", 1],
    ["Bola Society Pro", "Bolas", "Topper", 149.90, 19, "⚽", 0],
    ["Bola Basquete Evolution", "Bolas", "Wilson", 179.90, 13, "🏀", 1],
    ["Bola Vôlei Pro", "Bolas", "Penalty", 159.90, 17, "🏐", 0],
    ["Rede Vôlei Oficial", "Redes", "Penalty", 299.90, 8, "🥅", 0],
    ["Rede Futebol 7", "Redes", "Pangué", 349.90, 7, "🥅", 0],
    ["Camisa Dry Fit", "Roupas", "Adidas", 159.90, 28, "👕", 1],
    ["Shorts Training", "Roupas", "Nike", 129.90, 22, "🩳", 0],
    ["Agasalho Performance", "Roupas", "Mizuno", 299.90, 10, "🧥", 0],
    ["Luva de Goleiro Elite", "Acessórios", "Penalty", 239.90, 9, "🧤", 0],
    ["Óculos de Natação Pro", "Natação", "Speedo", 189.90, 16, "🥽", 0],
    ["Mochila Esportiva", "Acessórios", "Puma", 219.90, 14, "🎒", 0],
    ["Meião Futebol", "Acessórios", "Adidas", 59.90, 35, "🧦", 0],
    ["Corda de Pular Speed", "Fitness", "Mizuno", 69.90, 25, "〰️", 0],
    ["Kit Elástico Fitness", "Fitness", "Mizuno", 99.90, 18, "💪", 0]
  ];

  const stmt = db.prepare(`INSERT INTO produtos
    (nome,categoria,marca,preco,estoque,icone,destaque) VALUES (?,?,?,?,?,?,?)`);
  produtos.forEach(p => stmt.run(p));
  stmt.finalize();
}

app.get("/api/produtos", (req, res) => {
  const q = (req.query.q || "").trim();
  const categoria = (req.query.categoria || "").trim();
  let sql = "SELECT * FROM produtos WHERE 1=1";
  const params = [];

  if (q) {
    sql += " AND (nome LIKE ? OR marca LIKE ? OR categoria LIKE ?)";
    const term = `%${q}%`;
    params.push(term, term, term);
  }
  if (categoria) {
    sql += " AND categoria = ?";
    params.push(categoria);
  }
  sql += " ORDER BY destaque DESC, id DESC";

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
});

app.post("/api/produtos", (req, res) => {
  const { nome, categoria, marca, preco, estoque, icone = "🏆" } = req.body;
  if (!nome || !categoria || !marca || preco === undefined) {
    return res.status(400).json({ erro: "Preencha os campos obrigatórios." });
  }

  db.run(
    `INSERT INTO produtos (nome,categoria,marca,preco,estoque,icone)
     VALUES (?,?,?,?,?,?)`,
    [nome, categoria, marca, Number(preco), Number(estoque || 0), icone],
    function(err) {
      if (err) return res.status(500).json({ erro: err.message });
      res.status(201).json({ id: this.lastID });
    }
  );
});

app.put("/api/produtos/:id", (req, res) => {
  const { nome, categoria, marca, preco, estoque, icone } = req.body;
  db.run(
    `UPDATE produtos SET nome=?,categoria=?,marca=?,preco=?,estoque=?,icone=? WHERE id=?`,
    [nome, categoria, marca, Number(preco), Number(estoque), icone || "🏆", req.params.id],
    function(err) {
      if (err) return res.status(500).json({ erro: err.message });
      res.json({ atualizado: this.changes });
    }
  );
});

app.delete("/api/produtos/:id", (req, res) => {
  db.run("DELETE FROM produtos WHERE id=?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ removido: this.changes });
  });
});

app.get("/api/clientes", (req, res) => {
  db.all("SELECT * FROM clientes ORDER BY id DESC", (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
});

app.post("/api/clientes", (req, res) => {
  const { nome, telefone, email, cidade } = req.body;
  if (!nome) return res.status(400).json({ erro: "Informe o nome." });
  db.run(
    "INSERT INTO clientes (nome,telefone,email,cidade) VALUES (?,?,?,?)",
    [nome, telefone || "", email || "", cidade || ""],
    function(err) {
      if (err) return res.status(500).json({ erro: err.message });
      res.status(201).json({ id: this.lastID });
    }
  );
});

app.delete("/api/clientes/:id", (req, res) => {
  db.run("DELETE FROM clientes WHERE id=?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ erro: err.message });
    res.json({ removido: this.changes });
  });
});

app.post("/api/vendas", (req, res) => {
  const { cliente_id, forma_pagamento, itens } = req.body;
  if (!itens || !itens.length) return res.status(400).json({ erro: "Carrinho vazio." });

  db.serialize(() => {
    db.run("BEGIN TRANSACTION");

    const insertVenda = db.prepare(
      "INSERT INTO vendas (cliente_id,total,forma_pagamento) VALUES (?,?,?)"
    );

    let total = 0;
    for (const item of itens) total += Number(item.preco) * Number(item.quantidade);

    insertVenda.run([cliente_id || null, total, forma_pagamento || "Pix"], function(err) {
      if (err) {
        db.run("ROLLBACK");
        return res.status(500).json({ erro: err.message });
      }

      const vendaId = this.lastID;
      const itemStmt = db.prepare(
        "INSERT INTO itens_venda (venda_id,produto_id,quantidade,preco_unitario) VALUES (?,?,?,?)"
      );
      const estoqueStmt = db.prepare(
        "UPDATE produtos SET estoque = estoque - ? WHERE id = ? AND estoque >= ?"
      );

      let falhaEstoque = false;
      for (const item of itens) {
        itemStmt.run(vendaId, item.id, Number(item.quantidade), Number(item.preco));
        estoqueStmt.run(Number(item.quantidade), item.id, Number(item.quantidade), function(err2) {
          if (err2 || this.changes === 0) falhaEstoque = true;
        });
      }

      itemStmt.finalize();
      estoqueStmt.finalize();

      setTimeout(() => {
        if (falhaEstoque) {
          db.run("ROLLBACK");
          return res.status(400).json({ erro: "Estoque insuficiente para um dos produtos." });
        }
        db.run("COMMIT", err3 => {
          if (err3) return res.status(500).json({ erro: err3.message });
          res.status(201).json({ venda_id: vendaId, total });
        });
      }, 80);
    });
    insertVenda.finalize();
  });
});

app.get("/api/vendas", (req, res) => {
  db.all(
    `SELECT v.id, v.total, v.forma_pagamento, v.data, c.nome AS cliente
     FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id
     ORDER BY v.id DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ erro: err.message });
      res.json(rows);
    }
  );
});

app.get("/api/relatorios", (req, res) => {
  const sql = `
    SELECT
      (SELECT COUNT(*) FROM produtos) AS produtos,
      (SELECT COALESCE(SUM(estoque),0) FROM produtos) AS estoque,
      (SELECT COUNT(*) FROM clientes) AS clientes,
      (SELECT COUNT(*) FROM vendas) AS vendas,
      (SELECT COALESCE(SUM(total),0) FROM vendas) AS faturamento,
      (SELECT COALESCE(AVG(total),0) FROM vendas) AS ticket_medio
  `;
  db.get(sql, (err, resumo) => {
    if (err) return res.status(500).json({ erro: err.message });
    db.all(
      `SELECT categoria, COUNT(*) AS quantidade, COALESCE(SUM(estoque),0) AS estoque
       FROM produtos GROUP BY categoria ORDER BY quantidade DESC`,
      (err2, categorias) => {
        if (err2) return res.status(500).json({ erro: err2.message });
        db.all(
          `SELECT forma_pagamento, COUNT(*) AS quantidade, COALESCE(SUM(total),0) AS total
           FROM vendas GROUP BY forma_pagamento`,
          (err3, pagamentos) => {
            if (err3) return res.status(500).json({ erro: err3.message });
            res.json({ resumo, categorias, pagamentos });
          }
        );
      }
    );
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`SPORT+ PRO rodando em http://localhost:${PORT}`);
});