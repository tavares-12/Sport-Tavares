const page = location.pathname.split("/").pop().replace(".html","") || "index";
const routes = {index:"inicio",inicio:"inicio",produtos:"produtos",vendas:"vendas",relatorios:"relatorios",clientes:"clientes",configuracoes:"configuracoes"};

const state = {
  produtos: [],
  clientes: [],
  vendas: [],
  relatorio: null,
  carrinho: JSON.parse(localStorage.getItem("sportplus_cart") || "[]")
};

const money = v => Number(v || 0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const esc = s => String(s ?? "").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

function nav(active){
  return `
  <aside class="sidebar">
    <div class="brand">
      <div class="logo">S+</div>
      <div><strong>SPORT+ PRO</strong><small>SPORTS STORE</small></div>
    </div>
    <nav class="nav">
      <a class="${active==="inicio"?"active":""}" href="/index.html">🏠 <span>Início</span></a>
      <a class="${active==="produtos"?"active":""}" href="/produtos.html">🛍️ <span>Produtos</span></a>
      <a class="${active==="vendas"?"active":""}" href="/vendas.html">💳 <span>Vendas</span></a>
      <a class="${active==="relatorios"?"active":""}" href="/relatorios.html">📊 <span>Relatórios</span></a>
      <a class="${active==="clientes"?"active":""}" href="/clientes.html">👥 <span>Clientes</span></a>
      <a class="${active==="configuracoes"?"active":""}" href="/configuracoes.html">⚙️ <span>Configurações</span></a>
    </nav>
    <div class="sidebar-bottom"><div class="status"><span></span> Banco conectado</div></div>
  </aside>`;
}

function shell(active,title,subtitle,content){
  document.getElementById("app").innerHTML = `
    <div class="layout">${nav(active)}<main class="main">
      <header class="topbar"><div><h1>${title}</h1><p>${subtitle}</p></div><div class="user-chip"><div class="avatar">👤</div><div><strong>Administrador</strong><br><small>SPORT+ PRO</small></div></div></header>
      ${content}
      <div class="footer-note">SPORT+ PRO • Gestão esportiva simples, rápida e bonita.</div>
    </main></div>
    <div id="modal-root"></div>`;
}

async function api(url, options={}) {
  const r = await fetch(url,{headers:{"Content-Type":"application/json"},...options});
  const data = await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.erro || "Erro na operação");
  return data;
}

function saveCart(){localStorage.setItem("sportplus_cart",JSON.stringify(state.carrinho));}

async function loadPage(which){
  if(which==="inicio") return renderInicio();
  if(which==="produtos") return renderProdutos();
  if(which==="vendas") return renderVendas();
  if(which==="relatorios") return renderRelatorios();
  if(which==="clientes") return renderClientes();
  if(which==="configuracoes") return renderConfiguracoes();
}

async function renderInicio(){
  const r = await api("/api/relatorios");
  const produtos = await api("/api/produtos");
  shell("inicio","Visão geral","Tudo que acontece na SPORT+ PRO em um só lugar.",`
    <section class="hero">
      <h2>Venda mais. <b>Gerencie melhor.</b></h2>
      <p>Uma loja esportiva moderna para controlar produtos, estoque, clientes, vendas e resultados sem complicação.</p>
      <div class="actions">
        <a class="btn btn-primary" href="/produtos.html">🛍️ Ver produtos</a>
        <a class="btn btn-secondary" href="/vendas.html">💳 Nova venda</a>
      </div>
    </section>
    <section class="section grid grid-4">
      <div class="stat"><div class="icon">💰</div><small>Faturamento</small><strong>${money(r.resumo.faturamento)}</strong></div>
      <div class="stat"><div class="icon">📦</div><small>Produtos cadastrados</small><strong>${r.resumo.produtos}</strong></div>
      <div class="stat"><div class="icon">👥</div><small>Clientes</small><strong>${r.resumo.clientes}</strong></div>
      <div class="stat"><div class="icon">🧾</div><small>Vendas realizadas</small><strong>${r.resumo.vendas}</strong></div>
    </section>
    <section class="section">
      <div class="section-title"><h3>Produtos em destaque</h3><span>Mais procurados</span></div>
      <div class="products">${produtos.slice(0,4).map(productCard).join("")}</div>
    </section>`);
}

function productCard(p){
  return `<article class="product">
    <div class="product-art">${esc(p.icone || "🏆")}</div>
    <div class="product-body">
      <span class="badge">${esc(p.categoria)}</span>
      <h4>${esc(p.nome)}</h4>
      <div class="brand">${esc(p.marca)}</div>
      <div class="price">${money(p.preco)}</div>
      <div class="stock">${p.estoque} unidades em estoque</div>
      <div class="product-actions">
        <button class="btn btn-primary" onclick="addCart(${p.id})">+ Carrinho</button>
        <button class="btn btn-secondary" onclick="editProduct(${p.id})">Editar</button>
      </div>
    </div>
  </article>`;
}

async function renderProdutos(){
  state.produtos = await api("/api/produtos");
  const cats = [...new Set(state.produtos.map(p=>p.categoria))].sort();
  shell("produtos","Produtos","Catálogo completo da SPORT+ PRO.",`
    <div class="toolbar">
      <input id="search" class="input search" placeholder="🔎 Buscar por produto, marca ou categoria..." oninput="filterProducts()">
      <select id="category" class="select" onchange="filterProducts()"><option value="">Todas as categorias</option>${cats.map(c=>`<option>${esc(c)}</option>`).join("")}</select>
      <button class="btn btn-primary" onclick="openProductModal()">+ Novo produto</button>
    </div>
    <div id="product-grid" class="products">${state.produtos.map(productCard).join("")}</div>`);
}

function filterProducts(){
  const q = (document.getElementById("search").value||"").toLowerCase();
  const c = document.getElementById("category").value;
  const list = state.produtos.filter(p=>(!q || `${p.nome} ${p.marca} ${p.categoria}`.toLowerCase().includes(q)) && (!c || p.categoria===c));
  document.getElementById("product-grid").innerHTML = list.length ? list.map(productCard).join("") : `<div class="empty">Nenhum produto encontrado.</div>`;
}

function addCart(id){
  const p = state.produtos.find(x=>x.id===id);
  if(!p) return;
  const item = state.carrinho.find(x=>x.id===id);
  if(item) item.quantidade++;
  else state.carrinho.push({id:p.id,nome:p.nome,preco:p.preco,quantidade:1});
  saveCart();
  alert("Produto adicionado ao carrinho!");
}

function openProductModal(p=null){
  document.getElementById("modal-root").innerHTML = `<div class="modal-backdrop show" id="backdrop">
    <div class="modal">
      <div class="modal-head"><h3>${p?"Editar produto":"Novo produto"}</h3><button class="close" onclick="closeModal()">×</button></div>
      <form onsubmit="saveProduct(event,${p?.id||"null"})" class="form-grid">
        <label class="full">Nome<input class="input" name="nome" required value="${esc(p?.nome||"")}"></label>
        <label>Categoria<input class="input" name="categoria" required value="${esc(p?.categoria||"Tênis")}"></label>
        <label>Marca<input class="input" name="marca" required value="${esc(p?.marca||"Nike")}"></label>
        <label>Preço<input class="input" name="preco" type="number" step="0.01" required value="${p?.preco||""}"></label>
        <label>Estoque<input class="input" name="estoque" type="number" required value="${p?.estoque||0}"></label>
        <label>Ícone<input class="input" name="icone" value="${esc(p?.icone||"🏆")}"></label>
        <div class="full actions"><button class="btn btn-primary">${p?"Salvar alterações":"Cadastrar produto"}</button></div>
      </form>
    </div></div>`;
}
function closeModal(){document.getElementById("modal-root").innerHTML=""}
async function saveProduct(e,id){
  e.preventDefault();
  const data=Object.fromEntries(new FormData(e.target).entries());
  data.preco=Number(data.preco);data.estoque=Number(data.estoque);
  try{
    await api(id?`/api/produtos/${id}`:"/api/produtos",{method:id?"PUT":"POST",body:JSON.stringify(data)});
    closeModal();renderProdutos();
  }catch(err){alert(err.message)}
}
function editProduct(id){
  const p=state.produtos.find(x=>x.id===id);
  if(p) openProductModal(p);
}
async function deleteProduct(id){
  if(!confirm("Excluir este produto?")) return;
  await api(`/api/produtos/${id}`,{method:"DELETE"});
  renderProdutos();
}

async function renderVendas(){
  state.produtos=await api("/api/produtos");
  state.clientes=await api("/api/clientes");
  state.vendas=await api("/api/vendas");
  shell("vendas","Vendas","Monte o carrinho e finalize a venda.",`
    <div class="grid grid-2">
      <section class="card">
        <div class="section-title"><h3>Adicionar produtos</h3><span>${state.carrinho.length} item(ns)</span></div>
        <div class="toolbar"><input id="sale-search" class="input search" placeholder="🔎 Buscar produto..." oninput="renderSaleProducts()"></div>
        <div id="sale-products" class="grid grid-2"></div>
      </section>
      <section class="card">
        <div class="section-title"><h3>🛒 Carrinho</h3><span id="cart-total">${money(cartTotal())}</span></div>
        <div id="cart-list"></div>
        <div class="form-grid">
          <label class="full">Cliente<select id="sale-client" class="select"><option value="">Cliente avulso</option>${state.clientes.map(c=>`<option value="${c.id}">${esc(c.nome)}</option>`).join("")}</select></label>
          <label class="full">Pagamento<select id="sale-payment" class="select"><option>Pix</option><option>Cartão</option><option>Dinheiro</option><option>Transferência</option></select></label>
        </div>
        <div class="actions"><button class="btn btn-primary" onclick="finishSale()">Finalizar venda</button><button class="btn btn-secondary" onclick="clearCart()">Limpar</button></div>
      </section>
    </div>
    <section class="section card"><div class="section-title"><h3>Últimas vendas</h3><span>Histórico</span></div><div class="table-wrap">${salesTable()}</div></section>`);
  renderSaleProducts();renderCart();
}
function renderSaleProducts(){
  const q=(document.getElementById("sale-search")?.value||"").toLowerCase();
  const list=state.produtos.filter(p=>`${p.nome} ${p.marca}`.toLowerCase().includes(q)).slice(0,8);
  const el=document.getElementById("sale-products");
  if(el) el.innerHTML=list.map(p=>`<div class="stat"><small>${esc(p.marca)}</small><strong>${esc(p.nome)}</strong><small>${money(p.preco)} • estoque ${p.estoque}</small><div class="actions"><button class="btn btn-primary" onclick="addCartSale(${p.id})">Adicionar</button></div></div>`).join("");
}
function addCartSale(id){addCart(id);renderCart();}
function cartTotal(){return state.carrinho.reduce((s,i)=>s+i.preco*i.quantidade,0)}
function renderCart(){
  const el=document.getElementById("cart-list");if(!el)return;
  el.innerHTML=state.carrinho.length?state.carrinho.map(i=>`<div style="display:flex;justify-content:space-between;gap:10px;padding:12px 0;border-bottom:1px solid var(--border)"><div><strong>${esc(i.nome)}</strong><br><small>${i.quantidade} x ${money(i.preco)}</small></div><div><b>${money(i.preco*i.quantidade)}</b><br><button class="btn btn-danger" onclick="removeCart(${i.id})">Remover</button></div></div>`).join(""):`<div class="empty">Seu carrinho está vazio.</div>`;
  const total=document.getElementById("cart-total");if(total)total.textContent=money(cartTotal());
}
function removeCart(id){state.carrinho=state.carrinho.filter(i=>i.id!==id);saveCart();renderCart()}
function clearCart(){state.carrinho=[];saveCart();renderCart()}
async function finishSale(){
  if(!state.carrinho.length)return alert("Adicione produtos ao carrinho.");
  try{
    await api("/api/vendas",{method:"POST",body:JSON.stringify({cliente_id:document.getElementById("sale-client").value||null,forma_pagamento:document.getElementById("sale-payment").value,itens:state.carrinho})});
    alert("Venda registrada com sucesso!");
    state.carrinho=[];saveCart();renderVendas();
  }catch(err){alert(err.message)}
}
function salesTable(){
  if(!state.vendas.length)return `<div class="empty">Ainda não há vendas registradas.</div>`;
  return `<table><thead><tr><th>#</th><th>Cliente</th><th>Pagamento</th><th>Data</th><th>Total</th></tr></thead><tbody>${state.vendas.slice(0,8).map(v=>`<tr><td>#${v.id}</td><td>${esc(v.cliente||"Avulso")}</td><td>${esc(v.forma_pagamento)}</td><td>${new Date(v.data).toLocaleDateString("pt-BR")}</td><td><strong>${money(v.total)}</strong></td></tr>`).join("")}</tbody></table>`;
}

async function renderRelatorios(){
  state.relatorio=await api("/api/relatorios");
  const r=state.relatorio;
  const max=Math.max(...r.categorias.map(x=>x.quantidade),1);
  shell("relatorios","Relatórios","Acompanhe o desempenho da sua loja.",`
    <div class="grid grid-4">
      <div class="stat"><small>Faturamento</small><strong>${money(r.resumo.faturamento)}</strong></div>
      <div class="stat"><small>Ticket médio</small><strong>${money(r.resumo.ticket_medio)}</strong></div>
      <div class="stat"><small>Estoque total</small><strong>${r.resumo.estoque}</strong></div>
      <div class="stat"><small>Vendas</small><strong>${r.resumo.vendas}</strong></div>
    </div>
    <section class="section grid grid-2">
      <div class="card"><div class="section-title"><h3>Produtos por categoria</h3><span>Quantidade</span></div>
        <div class="chart">${r.categorias.map(c=>`<div class="bar-wrap"><div class="bar-value">${c.quantidade}</div><div class="bar" style="height:${Math.max(8,c.quantidade/max*210)}px"></div><div class="bar-label">${esc(c.categoria)}</div></div>`).join("")}</div>
      </div>
      <div class="card"><div class="section-title"><h3>Formas de pagamento</h3><span>Vendas</span></div>
        ${r.pagamentos.length?r.pagamentos.map(p=>`<div style="display:flex;justify-content:space-between;padding:15px 0;border-bottom:1px solid var(--border)"><span>${esc(p.forma_pagamento)}</span><strong>${p.quantidade} • ${money(p.total)}</strong></div>`).join(""):`<div class="empty">Sem dados ainda.</div>`}
      </div>
    </section>
    <div class="notice section">💡 Dica: use os relatórios para descobrir quais categorias estão girando mais e decidir o que comprar para repor o estoque.</div>`);
}

async function renderClientes(){
  state.clientes=await api("/api/clientes");
  shell("clientes","Clientes","Cadastre e organize seus clientes.",`
    <div class="toolbar"><button class="btn btn-primary" onclick="openClientModal()">+ Novo cliente</button></div>
    <section class="card table-wrap"><table><thead><tr><th>Nome</th><th>Telefone</th><th>E-mail</th><th>Cidade</th><th>Ações</th></tr></thead><tbody>
      ${state.clientes.map(c=>`<tr><td><strong>${esc(c.nome)}</strong></td><td>${esc(c.telefone)}</td><td>${esc(c.email)}</td><td>${esc(c.cidade)}</td><td><button class="btn btn-danger" onclick="deleteClient(${c.id})">Excluir</button></td></tr>`).join("")}
    </tbody></table></section>`);
}
function openClientModal(){
  document.getElementById("modal-root").innerHTML=`<div class="modal-backdrop show"><div class="modal"><div class="modal-head"><h3>Novo cliente</h3><button class="close" onclick="closeModal()">×</button></div><form onsubmit="saveClient(event)" class="form-grid">
    <label class="full">Nome<input class="input" name="nome" required></label>
    <label>Telefone<input class="input" name="telefone"></label><label>E-mail<input class="input" name="email" type="email"></label>
    <label class="full">Cidade<input class="input" name="cidade"></label>
    <div class="full actions"><button class="btn btn-primary">Cadastrar cliente</button></div>
  </form></div></div>`;
}
async function saveClient(e){e.preventDefault();await api("/api/clientes",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target).entries()))});closeModal();renderClientes()}
async function deleteClient(id){if(!confirm("Excluir este cliente?"))return;await api(`/api/clientes/${id}`,{method:"DELETE"});renderClientes()}

function renderConfiguracoes(){
  shell("configuracoes","Configurações","Preferências rápidas do sistema.",`
    <div class="grid grid-2">
      <section class="card"><div class="section-title"><h3>Sobre o projeto</h3></div>
        <p style="color:var(--muted);line-height:1.7">SPORT+ PRO é um sistema de loja esportiva feito com HTML, CSS, JavaScript, Node.js, Express e SQLite. O banco fica integrado ao servidor para cadastrar produtos, clientes e vendas.</p>
      </section>
      <section class="card"><div class="section-title"><h3>Estrutura</h3></div>
        <p>🏠 1. Início<br>🛍️ 2. Produtos<br>💳 3. Vendas<br>📊 4. Relatórios<br>👥 5. Clientes<br>⚙️ 6. Configurações</p>
      </section>
    </div>
    <section class="section card"><div class="section-title"><h3>Banco de dados</h3></div>
      <div class="notice">🟢 SQLite conectado pelo servidor. Os dados ficam salvos no arquivo <b>sportplus.db</b>.</div>
      <div class="actions"><button class="btn btn-secondary" onclick="localStorage.removeItem('sportplus_cart');alert('Carrinho local limpo.')">Limpar carrinho local</button></div>
    </section>`);
}

window.loadPage=loadPage;
window.renderProdutos=renderProdutos;
window.filterProducts=filterProducts;
window.addCart=addCart;
window.openProductModal=openProductModal;
window.closeModal=closeModal;
window.saveProduct=saveProduct;
window.editProduct=editProduct;
window.deleteProduct=deleteProduct;
window.addCartSale=addCartSale;
window.renderSaleProducts=renderSaleProducts;
window.removeCart=removeCart;
window.clearCart=clearCart;
window.finishSale=finishSale;
window.openClientModal=openClientModal;
window.saveClient=saveClient;
window.deleteClient=deleteClient;